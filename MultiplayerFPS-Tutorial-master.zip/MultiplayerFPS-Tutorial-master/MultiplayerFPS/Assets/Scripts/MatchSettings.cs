﻿[System.Serializable]
public class MatchSettings {

	public float respawnTime = 3f;

}
